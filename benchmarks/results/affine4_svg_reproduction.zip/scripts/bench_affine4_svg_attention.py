import gc
import hashlib
import importlib.util
import json
import random
import statistics
import sys
import time
from pathlib import Path
from types import SimpleNamespace

ROOT = Path('/Users/ariel/opt/3party/omlx/.worktrees/generic-affine4')
OLD = Path('/private/tmp/omlx-affine4-svg-old')
VLM = Path('/Users/ariel/opt/3party/mlx-vlm')
OUT = Path('/private/tmp/omlx-affine4-svg-comparison-20260907/attention.json')
sys.path[:0] = [str(ROOT), str(VLM)]
import mlx.core as mx
import omlx.affine4 as current
import mlx_vlm.affine4 as vlm

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

old = load('omlx.patches.affine4_legacy_probe', OLD / 'omlx/patches/affine4_attention.py')
ext = load('legacy_affine4._ext', OLD / 'omlx/custom_kernels/qwen35_prefill/_ext.cpython-311-darwin.so')
import omlx.custom_kernels.qwen35_prefill.fast as fast
fast.affine4_attention_available = lambda: ext.affine4_attention_kernels_built() and ext.is_nax_available()
fast.qwen35_affine4_attention = ext.qwen35_affine4_attention
assert fast.affine4_attention_available()
paths = [ROOT/'omlx/affine4.py', VLM/'mlx_vlm/affine4.py', OLD/'omlx/patches/affine4_attention.py', Path(__file__)]
result = {'protocol': 'M5 Pro, dense Qwen geometry: batch1, 24 query/4 KV heads, D256. Identical BF16 random Q/K/V, randomized interleaved attention dispatch, 10 warmups and 41 measured rounds. No model or other active GPU workload. Includes query rotation and attention; excludes KV conversion. Each codec encodes the same K/V separately.', 'source_sha256': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}, 'rows': []}
for tokens in [4096,8192,16384,32768]:
    mx.random.seed(123)
    k = mx.random.normal((1,4,tokens,256), dtype=mx.bfloat16)
    v = mx.random.normal(k.shape, dtype=mx.bfloat16)
    mx.eval(k,v)
    caches = {name: module.Affine4KVCache() for name,module in [('current',current),('vlm_pr',vlm)]}
    for cache in caches.values():
        cache.update_and_fetch(k,v)
        mx.eval(cache.state)
    codec = old.Affine4Codec(256)
    legacy = SimpleNamespace(keys=codec.quantize(k),values=codec.quantize(v),offset=tokens)
    mx.eval(legacy.keys,legacy.values)
    for qlen in [1,2,4]:
        q = mx.random.normal((1,24,qlen,256),dtype=mx.bfloat16)
        mx.eval(q)
        mask = None if qlen==1 else 'causal'
        cases = {name: (lambda c=c: c.decode_attention(q,scale=256**-.5,mask=mask)) for name,c in caches.items()}
        cases['original_omlx'] = lambda: old._native_decode(legacy,q,256**-.5,mask)
        cases['native_bf16'] = lambda: mx.fast.scaled_dot_product_attention(q,k,v,scale=256**-.5,mask=mask)
        for _ in range(10):
            for call in cases.values():
                value = call()
                assert value is not None
                mx.eval(value)
        samples = {name: [] for name in cases}
        rng = random.Random(99)
        for _ in range(41):
            order = list(cases)
            rng.shuffle(order)
            for name in order:
                start = time.perf_counter_ns()
                mx.eval(cases[name]())
                samples[name].append((time.perf_counter_ns()-start)/1e6)
        row = {'context':tokens,'query_length':qlen,'milliseconds':{name:{'median':statistics.median(a),'p10':sorted(a)[4],'p90':sorted(a)[36]} for name,a in samples.items()},'current_native':str(current._NATIVE_LAUNCHABLE),'old_native':old.diagnostics(),'vlm_native':str(vlm._NATIVE_LAUNCHABLE)}
        result['rows'].append(row)
        OUT.write_text(json.dumps(result,indent=2)+'\n')
        print(json.dumps(row),flush=True)
    del caches,legacy,k,v,q,cache,cases,value
    gc.collect()
    mx.clear_cache()
print('DONE',flush=True)
