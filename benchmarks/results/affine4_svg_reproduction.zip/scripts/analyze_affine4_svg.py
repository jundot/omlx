import json
import statistics
from pathlib import Path
from tokenizers import Tokenizer
root=Path('/private/tmp/omlx-affine4-svg-comparison-20260907')
data=json.loads((root/'results.json').read_text())
def count(s):
    return sum(s[k] for k in ('init_emits','draft_emits','bonus_emits','verify_emits'))
summary={'runs':[],'groups':[],'windows':[],'manual_chat':{'prompt':'draw dinosaur using plain svg','prompt_tokens':57,'completion_tokens':28903,'total_seconds':1125.01,'generation_tps':25.7,'ui_thinking_tokens_approx':18286,'ui_thinking_seconds':806.5,'ui_thinking_tps_approx':18286/806.5,'ui_answer_tokens_approx':10617,'ui_answer_seconds_approx':1125.01-.8-806.5,'ui_answer_tps_approx':10617/(1125.01-.8-806.5),'mtp_cycles':10260,'mtp_emitted_tokens':28904,'mtp_accepts':18642,'mtp_considered_drafts':23375,'mtp_backbone_ms':1050813.2,'mtp_head_ms':61932.4,'cache_boundary_logged_ms':1.5+151+197.4,'source':'manual-server.log 2026-09-07 16:27:13; browser final stats observed after completion. Thinking tokens are the last server-polled count while thinking, not an exact retokenization.'}}
for run in data['runs']:
    s=run['trace'][-1]
    row={'label':run['label'],'version':run['label'].split('-')[0],'thinking':run['thinking'],'seed':run['seed'],'tokens':run['usage']['completion_tokens'],'generation_seconds':run['usage']['generation_duration'],'tps':run['usage']['generation_tokens_per_second'],'cycles':s['cycles'],'emits':count(s),'accepts':s['accepts'],'considered_drafts':sum(s['depth_drafted']),'tokens_per_cycle':count(s)/s['cycles'],'accept_percent':100*s['accepts']/sum(s['depth_drafted']),'backbone_ms_per_cycle':s['backbone_ms']/s['cycles'],'head_ms_per_cycle':s['mtp_head_ms']/s['cycles'],'zero_cycles':s['zero_cycles'],'finish':run['finish'],'prompt_tokens':run['usage']['prompt_tokens'],'cached_tokens':run['usage']['prompt_tokens_details']['cached_tokens']}
    summary['runs'].append(row)
    for a,b in zip(run['trace'],run['trace'][1:]):
        n=count(b)-count(a)
        c=b['cycles']-a['cycles']
        d=sum(b['depth_drafted'])-sum(a['depth_drafted'])
        if n<=0 or c<=0: continue
        summary['windows'].append({'label':run['label'],'start':count(a),'end':count(b),'tps':n/(b['monotonic']-a['monotonic']),'tokens_per_cycle':n/c,'accept_percent':100*(b['accepts']-a['accepts'])/d if d else None,'backbone_ms_per_cycle':(b['backbone_ms']-a['backbone_ms'])/c})
for thinking in (True,False):
    for version in ('old','current'):
        rows=[r for r in summary['runs'] if r['thinking']==thinking and r['version']==version]
        if not rows: continue
        cycles=sum(r['cycles'] for r in rows)
        summary['groups'].append({'version':version,'thinking':thinking,'runs':len(rows),'pooled_tps':sum(r['tokens'] for r in rows)/sum(r['generation_seconds'] for r in rows),'tokens_per_cycle':sum(r['emits'] for r in rows)/cycles,'accept_percent':100*sum(r['accepts'] for r in rows)/sum(r['considered_drafts'] for r in rows),'backbone_ms_per_cycle':sum(r['backbone_ms_per_cycle']*r['cycles'] for r in rows)/cycles,'head_ms_per_cycle':sum(r['head_ms_per_cycle']*r['cycles'] for r in rows)/cycles})
tokenizer=Tokenizer.from_file('/Users/ariel/.omlx/models/Jundot/Qwen3.8-27B-oQ4e-mtp/tokenizer.json')
summary['output_comparisons']=[]
for seed in (17,29):
    for thinking in (True,False):
        field='reasoning_content' if thinking else 'content'
        files=[root/f'{v}-seed{seed}-thinking-{str(thinking).lower()}.{field}.txt' for v in ('current','old')]
        if not all(p.exists() for p in files): continue
        ids=[tokenizer.encode(p.read_text(),add_special_tokens=False).ids for p in files]
        common=next((i for i,(a,b) in enumerate(zip(*ids)) if a!=b),min(map(len,ids)))
        summary['output_comparisons'].append({'seed':seed,'thinking':thinking,'retokenized_lengths':list(map(len,ids)),'common_prefix_tokens':common})
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for group in summary['groups']: print(json.dumps(group))
print('outputs',summary['output_comparisons'])
