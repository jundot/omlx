import dataclasses
import json
import sys
import time
from pathlib import Path

source, trace = sys.argv[1:3]
sys.path.insert(0, source)
sys.argv = [sys.argv[0], *sys.argv[3:]]
from omlx.patches.mlx_lm_mtp import batch_generator as bg

trace_file = open(trace, 'a', buffering=1)
last = {}

def snapshot(uid, stats, event, **extra):
    value = dataclasses.asdict(stats)
    value.update(uid=str(uid), event=event, monotonic=time.monotonic(), **extra)
    trace_file.write(json.dumps(value) + '\n')

original_emit = bg._emit_response
original_log = bg._log_mtp_stats

def emit(batch, token, logprobs, stats=None):
    if stats is not None:
        uid = str(batch.uids[0])
        count = stats.init_emits + stats.draft_emits + stats.bonus_emits + stats.verify_emits
        if uid not in last or count < last[uid]:
            snapshot(uid, stats, 'start', token=int(token))
        if count % 512 == 0:
            snapshot(uid, stats, 'window', token=int(token))
        last[uid] = count
    return original_emit(batch, token, logprobs, stats)

def log(uid, stats, finish_reason):
    snapshot(uid, stats, 'finish', finish_reason=finish_reason)
    return original_log(uid, stats, finish_reason)

bg._emit_response = emit
bg._log_mtp_stats = log
from omlx.cli import main
main()
