import copy
import json
import os
import shutil
import subprocess
import time
import urllib.request
from pathlib import Path

PYTHON = '/Users/ariel/opt/3party/omlx/.venv/bin/python'
NEW = Path('/Users/ariel/opt/3party/omlx/.worktrees/generic-affine4')
OLD = Path('/private/tmp/omlx-affine4-svg-old')
ORIGINAL = Path('/Users/ariel/opt/3party/omlx')
ROOT = Path('/private/tmp/omlx-affine4-svg-comparison-20260907/long-control')
MANUAL = Path('/private/tmp/omlx-affine4-comparison-20260907')
ROOT.mkdir(exist_ok=True)
for filename in ('_ext.cpython-311-darwin.so', 'libomlx_qwen35_prefill_kernel_ops.dylib', 'omlx_qwen35_prefill_kernels.metallib', 'omlx_qwen35_prefill_kernels_nax.metallib'):
    rel = Path('omlx/custom_kernels/qwen35_prefill') / filename
    shutil.copy2(ORIGINAL / rel, OLD / rel)

settings = json.loads((MANUAL / 'settings.json').read_text())
model_settings = json.loads((MANUAL / 'model_settings.json').read_text())['models']['Qwen3.8-27B']
results = {'protocol': {'model': '/Users/ariel/.omlx/models/Jundot/Qwen3.8-27B-oQ4e-mtp', 'prompt': 'Draw dinosaurs using plain SVG. Output only SVG markup, without Markdown or tool calls. Create a detailed illustrated scene with a large dinosaur, a smaller dinosaur, trees, rocks, mountains, clouds, layered gradients and fine decorative details. Make it a long, complete SVG of at least 600 lines, with every shape explicitly included.', 'old': '1ee0d24a', 'current': 'b8c3d1da', 'temperature': 1.0, 'top_p': .95, 'top_k': 0, 'repetition_penalty': 1.0, 'max_tokens': 8192, 'mtp': True, 'skip_last': True, 'notes': 'Sequential isolated HTTP servers; same dependencies and weights; thinking-off is a control, not a replay of the original answer prefix.'}, 'runs': []}
headers = {'Authorization': 'Bearer affine4-comparison', 'Content-Type': 'application/json'}

def request(path, payload=None):
    data = None if payload is None else json.dumps(payload).encode()
    return urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:8004' + path, data=data, headers=headers), timeout=900)

def generate(label, thinking, seed, limit=8192, prompt=None):
    payload = {'model': 'Qwen3.8-27B', 'messages': [{'role': 'user', 'content': prompt or 'Draw dinosaurs using plain SVG. Output only SVG markup, without Markdown or tool calls. Create a detailed illustrated scene with a large dinosaur, a smaller dinosaur, trees, rocks, mountains, clouds, layered gradients and fine decorative details. Make it a long, complete SVG of at least 600 lines, with every shape explicitly included.'}], 'temperature': 1.0, 'top_p': .95, 'top_k': 0, 'repetition_penalty': 1.0, 'seed': seed, 'max_tokens': limit, 'chat_template_kwargs': {'enable_thinking': thinking}, 'stream': True, 'stream_options': {'include_usage': True}}
    start = time.monotonic()
    phases = {'reasoning_content': {'text': '', 'first': None, 'last': None}, 'content': {'text': '', 'first': None, 'last': None}}
    usage = None
    finish = None
    with open(ROOT / (label + '.sse.jsonl'), 'w') as stream, request('/v1/chat/completions', payload) as response:
        for raw in response:
            if not raw.startswith(b'data: '):
                continue
            raw = raw[6:].strip()
            if raw == b'[DONE]':
                break
            value = json.loads(raw)
            elapsed = time.monotonic() - start
            stream.write(json.dumps({'elapsed': elapsed, 'data': value}) + '\n')
            if value.get('error'):
                raise RuntimeError(value['error'])
            if value.get('usage'):
                usage = value['usage']
            for choice in value.get('choices', []):
                finish = choice.get('finish_reason') or finish
                delta = choice.get('delta', {})
                for name in phases:
                    chunk = delta.get(name)
                    if chunk:
                        phase = phases[name]
                        phase['text'] += chunk
                        if phase['first'] is None:
                            phase['first'] = elapsed
                        phase['last'] = elapsed
    elapsed = time.monotonic() - start
    for name, value in phases.items():
        (ROOT / (label + '.' + name + '.txt')).write_text(value.pop('text'))
    result = {'label': label, 'thinking': thinking, 'seed': seed, 'limit': limit, 'elapsed': elapsed, 'phases': phases, 'usage': usage, 'finish': finish, 'request': payload}
    print(json.dumps(result), flush=True)
    return result

blocks = [('current', NEW, 41, [False]), ('old', OLD, 41, [False])]
for version, source, seed, order in blocks:
    base = ROOT / f'{version}-seed{seed}'
    base.mkdir(exist_ok=True)
    (base / 'models').mkdir(exist_ok=True)
    model_link = base / 'models/Qwen3.8-27B'
    if not model_link.exists():
        model_link.symlink_to(results['protocol']['model'])
    cfg = copy.deepcopy(settings)
    cfg['server']['port'] = 8004
    cfg['model']['model_dirs'] = [str(base / 'models')]
    cfg['model']['model_dir'] = str(base / 'models')
    cfg['auth'].pop('secret_key', None)
    (base / 'settings.json').write_text(json.dumps(cfg, indent=2))
    mcfg = copy.deepcopy(model_settings)
    mcfg['max_tokens'] = 8192
    if version == 'old':
        mcfg.pop('turboquant_kv_scheme', None)
    (base / 'model_settings.json').write_text(json.dumps({'version': 1, 'models': {'Qwen3.8-27B': mcfg}}, indent=2))
    env = os.environ.copy()
    env.pop('OMLX_AFFINE4_KV', None)
    env['PYTHONPATH'] = str(source)
    if version == 'old':
        env['OMLX_AFFINE4_KV'] = '1'
    trace = base / 'mtp.jsonl'
    with open(base / 'server.log', 'w') as logfile:
        process = subprocess.Popen([PYTHON, '/private/tmp/serve_affine4_svg_probe.py', str(source), str(trace), 'serve', '--base-path', str(base), '--host', '127.0.0.1', '--port', '8004', '--api-key', 'affine4-comparison'], cwd=source, env=env, stdout=logfile, stderr=subprocess.STDOUT)
        print(f'START {version} seed={seed} pid={process.pid}', flush=True)
        try:
            for attempt in range(150):
                if process.poll() is not None:
                    raise RuntimeError(f'Server exited {process.returncode}; {base / "server.log"}')
                try:
                    with request('/v1/models') as response:
                        json.load(response)
                    break
                except Exception:
                    time.sleep(1)
            else:
                raise TimeoutError('Server startup')
            generate(f'{version}-seed{seed}-warmup', False, 101, 128, 'Write a detailed SVG scene. ' + 'A green dinosaur walks through a forest. ' * 150)
            for thinking in order:
                label = f'{version}-seed{seed}-thinking-{str(thinking).lower()}'
                trace_start = len(trace.read_text().splitlines()) if trace.exists() else 0
                result = generate(label, thinking, seed)
                result['trace'] = [json.loads(line) for line in trace.read_text().splitlines()[trace_start:]]
                results['runs'].append(result)
                (ROOT / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
        finally:
            process.terminate()
            try:
                process.wait(timeout=30)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
        time.sleep(3)
print('COMPLETED ' + str(ROOT / 'results.json'), flush=True)
