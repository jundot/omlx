# Affine4 optimization validation

Apple M5 Pro, 48 GiB; MLX 0.32.2, mlx-lm 0.31.3, installed mlx-vlm 0.6.3.
The shared-model comparison imports the separate mlx-vlm checkout at 10f9030d.
The server uses installed mlx-vlm. Native model KV is BF16.
The included code/test/harness patch applies to oMLX upstream aa8db734 and
reconstructs the implementation through 99d314fd without needing private refs.

Scripts retain this machine's local paths. Adjust checkout, model and temporary
paths before replaying. Model weights are not included. Run GPU workloads
sequentially with other GPU jobs stopped. HTTP scripts mutate only the isolated
server's selected model settings and caches. No public upload is enabled.

Source mapping:
- decode_optimized: current=6805ce1f, baseline=423c2d35 (probes/affine4_baseline.py).
- prefill_optimized: current=41262a64, same baseline.
- query/mask_tuning: current=2f487029 plus the named isolated probe files.
- partition probes: current=probes/affine4_mask_tuning.py, before 99d314fd.
  Restore that source before replaying: their three-argument override predates
  the final dispatch's additional row-count argument.
- incremental large server: 2f487029. Mask/partition tuning came afterward.
- final shared model, server comparison and cache smoke: 99d314fd core.
The large server's empty-cache availability diagnostic was incorrect until
8617fa3f; chunk logs correctly record boundary_enabled=True.

Start serve_affine4_long.py with the isolated base path and port from the scripts.
Run run_affine4_incremental_comparison.py, then smoke.py cold. Stop and restart
the server before smoke.py restart, followed by smoke.py mtp.
The long script separately checks Qwen3.8 at 200K/150K and Qwen3.6 at 200K.

Original oMLX comparisons additionally require its compiled extension at
1ee0d24a; the previous affine4_regression_reproduction.zip contains that
investigation's source and harness. VLM cache source is included here.

One vmmap snapshot was taken during the Qwen3.8 200K prefill. Physical footprint
is sampled and is not the MLX active-allocation high-water mark. Shared-model
decode retains a native cache snapshot, so its memory is not standalone usage.
See adjacent JSON results and affine4_incremental_validation.md for protocols,
limitations, measured performance and cache lifecycle outcomes.
