import json
import re
from pathlib import Path

root = Path('/Users/ariel/opt/3party/omlx/.worktrees/generic-affine4')
log = Path('/private/tmp/omlx-affine4-comparison-20260907/incremental-server.log')
requests = [
    ('Qwen3.8-27B', 200000, 'e95b7e1a-2490-4b0f-afca-8530ffdc9e2d', 19936, 65536),
    ('Qwen3.8-27B', 150000, '59e5e270-3280-4a0d-98a8-31fe080889a4', 19936, 65536),
    ('Qwen3.6-35B-A3B', 200000, 'f5b85acc-9ec4-4764-9602-270ce7280850', 6800, 20480),
]
traces = []
for line in log.read_text().splitlines():
    if '[benchmark-memory]' not in line:
        continue
    fields = dict(re.findall(r'(\w+)=([^\s]+)', line))
    traces.append({k: int(v) if v.isdecimal() else v for k, v in fields.items()})
results = json.loads((root / 'benchmarks/results/affine4_incremental_large_context.json').read_text())
data = {
    'units': 'bytes unless explicitly suffixed _gib',
    'log': log.name,
    'implementation_commit': '2f487029',
    'interpretation': 'Cache nbytes includes recurrent state and allocated capacity. MLX peak is an allocator high-water mark. Physical footprint and pool peaks are sampled, not simultaneous or additive. Chunk traces supplement the 250 ms sampler.',
    'runs': [],
}
for model, context, rid, compressed, native in requests:
    rows = [r for r in traces if r['rid'] == rid]
    assert rows and max(r['context'] for r in rows) == context
    final = next(r for r in reversed(rows) if r['phase'] == 'after_reclaim')
    result = next(r['result']['results'][0] for r in results['runs'] if r['model'] == model and r['context'] == context)
    data['runs'].append({
        'model': model, 'context': context, 'request_id': rid,
        'trace_samples': len(rows),
        'cache_bytes_per_token': compressed,
        'native_kv_bytes_per_token': native,
        'logical_attention_cache_bytes': compressed * context,
        'native_attention_cache_bytes': native * context,
        'last_prefill_trace': final,
        'trace_maxima': {k: max(r[k] for r in rows) for k in final if k.endswith('_bytes')},
        'mlx_active_high_water_bytes': result['peak_memory_bytes'],
        'periodic_sampler_peaks_gib': result['system_metrics']['memory'],
    })
(root / 'benchmarks/results/affine4_incremental_memory.json').write_text(json.dumps(data, indent=2)+'\n')
print(json.dumps([{'model': r['model'], 'context': r['context'], 'cache_gib': r['last_prefill_trace']['cache_bytes']/2**30, 'trace_phys_gib': r['trace_maxima']['phys_footprint_bytes']/2**30} for r in data['runs']], indent=2))
