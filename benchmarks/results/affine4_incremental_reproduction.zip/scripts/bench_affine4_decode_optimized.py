import gc
import hashlib
import importlib.util
import json
import random
import statistics
import sys
import time
from pathlib import Path
from types import SimpleNamespace

ROOT = Path('/Users/ariel/opt/3party/omlx/.worktrees/generic-affine4')
OLD = Path('/Users/ariel/opt/3party/omlx')
VLM = Path('/Users/ariel/opt/3party/mlx-vlm')
sys.path[:0] = [str(ROOT), str(VLM)]
import mlx.core as mx
import omlx.affine4 as current
import mlx_vlm.affine4 as vlm

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

baseline = load('omlx.affine4_baseline', Path('/private/tmp/affine4_baseline.py'))
old = load('omlx.patches.affine4_legacy_probe', OLD / 'omlx/patches/affine4_attention.py')
ext = load('legacy_affine4._ext', OLD / 'omlx/custom_kernels/qwen35_prefill/_ext.cpython-311-darwin.so')
import omlx.custom_kernels.qwen35_prefill.fast as fast
fast.affine4_attention_available = lambda: ext.affine4_attention_kernels_built() and ext.is_nax_available()
fast.qwen35_affine4_attention = ext.qwen35_affine4_attention
assert fast.affine4_attention_available()

output = ROOT/'benchmarks/results/affine4_decode_optimized.json'
result = {'protocol': 'Same BF16 random Q/K/V, randomized interleaved attention dispatch, 10 warmups, 41 rounds. No model/server/MTP. Baseline is commit 423c2d35; current uses bounded FP16 accumulation.',
          'sources': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'omlx/affine4.py', VLM/'mlx_vlm/affine4.py', OLD/'omlx/patches/affine4_attention.py']}, 'rows': []}
def save():
    output.write_text(json.dumps(result, indent=2)+'\n')

for hq, hkv in [(24, 4), (16, 2)]:
    for tokens in [32768, 200000]:
        mx.random.seed(123)
        k = mx.random.normal((1,hkv,tokens,256), dtype=mx.bfloat16)
        v = mx.random.normal(k.shape, dtype=mx.bfloat16)
        mx.eval(k,v)
        caches = {name: module.Affine4KVCache() for name,module in [('current',current), ('vlm_pr',vlm), ('baseline_fp32',baseline)]}
        for c in caches.values():
            c.update_and_fetch(k,v)
            mx.eval(c.state)
        legacy = None
        if hq == 24:
            codec = old.Affine4Codec(256)
            legacy = SimpleNamespace(keys=codec.quantize(k), values=codec.quantize(v), offset=tokens)
            mx.eval(legacy.keys,legacy.values)
        for qlen in [1,4]:
            q = mx.random.normal((1,hq,qlen,256), dtype=mx.bfloat16)
            mx.eval(q)
            mask = None if qlen == 1 else 'causal'
            cases = {name: (lambda c=c: c.decode_attention(q,scale=256**-.5,mask=mask)) for name,c in caches.items()}
            cases['native_bf16'] = lambda: mx.fast.scaled_dot_product_attention(q,k,v,scale=256**-.5,mask=mask)
            if legacy is not None:
                cases['original_omlx'] = lambda: old._native_decode(legacy,q,256**-.5,mask)
            for _ in range(10):
                for call in cases.values():
                    value = call()
                    assert value is not None
                    mx.eval(value)
            samples = {name: [] for name in cases}
            rng = random.Random(99)
            for _ in range(41):
                order = list(cases)
                rng.shuffle(order)
                for name in order:
                    start = time.perf_counter_ns()
                    mx.eval(cases[name]())
                    samples[name].append((time.perf_counter_ns()-start)/1e6)
            row = {'query_heads':hq,'kv_heads':hkv,'tokens':tokens,'query_length':qlen,
                   'milliseconds':{name:{'median':statistics.median(a),'p10':sorted(a)[4],'p90':sorted(a)[36]} for name,a in samples.items()},
                   'current_native':str(current._NATIVE_LAUNCHABLE), 'vlm_native':str(vlm._NATIVE_LAUNCHABLE)}
            result['rows'].append(row)
            save()
            print(json.dumps(row),flush=True)
        del cases,caches,legacy,k,v,q,c
        gc.collect()
        mx.clear_cache()
print('DONE', flush=True)
