import hashlib
import json
import sys
from pathlib import Path
import httpx

root = Path('/Users/ariel/opt/3party/omlx/.worktrees/generic-affine4')
path = root / 'benchmarks/results/affine4_incremental_smoke.json'
phase = sys.argv[1]
model = 'Qwen3.8-27B'
prefix = 'The verification code is 42. Remember it for the final question.\n' + ''.join(
    f'Reference row {i}: the recorded marker is amber.\n' for i in range(512)
)
data = json.loads(path.read_text()) if path.exists() else {
    'model': model,
    'source_sha256': hashlib.sha256((root / 'omlx/affine4.py').read_bytes()).hexdigest(),
    'cases': [],
}
with httpx.Client(base_url='http://127.0.0.1:8003', timeout=180, follow_redirects=True,
                  headers={'Authorization':'Bearer affine4-comparison'}) as client:
    client.get('/admin/auto-login',params={'key':'affine4-comparison','redirect':'/admin/dashboard'}).raise_for_status()
    if phase == 'cold':
        settings = {'turboquant_kv_enabled':True,'turboquant_kv_scheme':'affine4',
                    'turboquant_kv_bits':4,'turboquant_skip_last':True,
                    'mtp_enabled':False,'vlm_mtp_enabled':False,'enable_thinking':False}
        client.put(f'/admin/api/models/{model}/settings',json=settings).raise_for_status()
        for cache in ('ssd-cache','hot-cache'):
            client.post(f'/admin/api/{cache}/clear',json={}).raise_for_status()
    if phase == 'mtp':
        client.put(f'/admin/api/models/{model}/settings',json={'mtp_enabled':True}).raise_for_status()
    cases = ['cold','warm'] if phase == 'cold' else [phase]
    for case in cases:
        question = 'What is the verification code? Reply with just the number.'
        if phase == 'mtp':
            question = 'State the verification code, then count from 1 to 20 in order, separated by spaces.'
        body = {'model':model,'messages':[{'role':'user','content':prefix+question}],
                'max_tokens':128,'temperature':0,'chat_template_kwargs':{'enable_thinking':False}}
        response = client.post('/v1/chat/completions',json=body)
        response.raise_for_status()
        result = response.json()
        row = {'case':case,'result':result}
        data['cases'].append(row)
        path.write_text(json.dumps(data,indent=2)+'\n')
        content = result['choices'][0]['message']['content'].strip()
        assert '42' in content if phase == 'mtp' else content == '42', content
        if phase == 'mtp':
            assert '19 20' in content, content
        usage = result['usage']
        cached = usage.get('prompt_tokens_details',{}).get('cached_tokens',0)
        if case == 'cold':
            assert cached == 0, usage
        else:
            assert cached >= 2048, usage
        row['validated'] = True
        path.write_text(json.dumps(data,indent=2)+'\n')
        print(json.dumps(row),flush=True)
