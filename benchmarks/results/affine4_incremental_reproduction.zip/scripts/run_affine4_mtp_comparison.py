import json
import os
import sys
from pathlib import Path

root = Path('/Users/ariel/opt/3party/omlx/.worktrees/generic-affine4')
sys.path.insert(0, str(root / 'benchmarks'))
import bench_affine4_server as bench

mtp_enabled = False
original_request = bench.request
def request(client, method, path, **kwargs):
    if method == 'PUT' and path.endswith('/settings'):
        kwargs['json']['mtp_enabled'] = mtp_enabled
    return original_request(client, method, path, **kwargs)

def plan(models):
    global mtp_enabled
    for mtp_enabled in (False, True):
        yield models[0], 'affine4', 'mtp_on' if mtp_enabled else 'mtp_off', [8192], 128

bench.plan = plan
bench.request = request
os.environ['OMLX_API_KEY'] = 'affine4-comparison'
path = root / 'benchmarks/results/affine4_incremental_mtp_comparison.json'
sys.argv = [__file__, '--models', 'Qwen3.8-27B', '--output', str(path)]
bench.main()
data = json.loads(path.read_text())
data['method']['repeat'] = 'Two cold 8K/128 generation controls: Lightning MTP disabled then enabled'
data['method']['speculation'] = 'Lightning MTP toggled in recorded settings; VLM MTP, DFlash, SpecPrefill and ANE disabled'
data['method']['implementation_commit'] = '99d314fd'
path.write_text(json.dumps(data, indent=2)+'\n')
