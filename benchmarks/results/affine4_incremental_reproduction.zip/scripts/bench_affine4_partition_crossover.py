import hashlib
import json
import random
import statistics
import sys
import time
from pathlib import Path
root=Path('/Users/ariel/opt/3party/omlx/.worktrees/generic-affine4')
sys.path[:0]=[str(root),'/Users/ariel/opt/3party/mlx-vlm']
import mlx.core as mx
import omlx.affine4 as current
import mlx_vlm.affine4 as legacy
original=current._attention_blocks
output=root/'benchmarks/results/affine4_partition_crossover.json'
data={'protocol':'Identical BF16 tensors, 10 warmups, 41 interleaved rounds. Target group count is an isolated dispatch override. Native range guard remains enabled.',
      'source_sha256':hashlib.sha256((root/'omlx/affine4.py').read_bytes()).hexdigest(),'rows':[]}
for hq,hkv in [(16,2),(32,1)]:
    for tokens in [65536,100000,150000,200000]:
        mx.random.seed(123)
        k=mx.random.normal((1,hkv,tokens,256),dtype=mx.bfloat16)
        v=mx.random.normal(k.shape,dtype=mx.bfloat16)
        c=current.Affine4KVCache()
        old=legacy.Affine4KVCache()
        c.update_and_fetch(k,v)
        old.update_and_fetch(k,v)
        mx.eval(c.state,old.state)
        for qlen in ([4] if hkv == 2 else [1]):
            q=mx.random.normal((1,hq,qlen,256),dtype=mx.bfloat16)
            mx.eval(q)
            mask='causal' if qlen>1 else None
            def call(name):
                if name=='vlm_pr':
                    return old.decode_attention(q,scale=256**-.5,mask=mask)
                current._attention_blocks=lambda t,h,d: min((t+63)//64,max(1,(int(name)+h-1)//h))
                result=current._native_attention(c,q,*c.state,256**-.5,mask)
                assert result is not None
                return result
            names=['168','336','vlm_pr']
            for _ in range(10):
                for name in names:
                    mx.eval(call(name))
            samples={name:[] for name in names}
            rng=random.Random(123)
            for _ in range(41):
                order=names[:]
                rng.shuffle(order)
                for name in order:
                    before=time.perf_counter_ns()
                    mx.eval(call(name))
                    samples[name].append((time.perf_counter_ns()-before)/1e6)
            reference=call('168').astype(mx.float32)
            errors={}
            for name in names[:-1]:
                result=call(name).astype(mx.float32)
                errors[name]={'finite':bool(mx.all(mx.isfinite(result)).item()),'max_abs_vs_168':float(mx.max(mx.abs(result-reference)).item())}
            row={'query_heads':hq,'kv_heads':hkv,'tokens':tokens,'query_length':qlen,'milliseconds':{n:statistics.median(a) for n,a in samples.items()},'numerics':errors}
            data['rows'].append(row)
            output.write_text(json.dumps(data,indent=2)+'\n')
            print(json.dumps(row),flush=True)
        del c,old,k,v,q,reference,result
        mx.clear_cache()
current._attention_blocks=original
print('DONE',flush=True)
