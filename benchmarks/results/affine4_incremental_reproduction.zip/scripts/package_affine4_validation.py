import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

root = Path('/Users/ariel/opt/3party/omlx/.worktrees/generic-affine4')
temporary = Path('/private/tmp')
results = root / 'benchmarks/results'
files = {}
scripts = [
    'bench_affine4_decode_optimized.py', 'bench_affine4_prefill_optimized.py',
    'bench_affine4_query_tuning.py', 'bench_affine4_mask_tuning.py',
    'bench_affine4_partitions.py', 'bench_affine4_partition_crossover.py',
    'bench_affine4_partition_threshold.py', 'bench_affine4_final_same_model.py',
    'run_affine4_incremental_long.py', 'run_affine4_incremental_comparison.py',
    'run_affine4_incremental_smoke.py', 'serve_affine4_long.py',
    'run_affine4_mtp_comparison.py',
    'summarize_affine4_memory.py', 'write_affine4_validation_report.py',
    'package_affine4_validation.py',
]
for name in scripts:
    files['scripts/' + name] = (temporary / name).read_bytes()
for name in ['affine4_baseline.py', 'affine4_before_query_tuning.py',
             'affine4_cooperative_queries.py', 'affine4_query_mask_tuning.py',
             'affine4_mask_tuning.py']:
    files['probes/' + name] = (temporary / name).read_bytes()
for revision in ['6805ce1f', '41262a64', '2f487029', '99d314fd']:
    paths = ['omlx/affine4.py']
    if revision in ['2f487029', '99d314fd']:
        paths += ['omlx/scheduler.py', 'omlx/memory_monitor.py',
                  'omlx/admin/benchmark.py', 'omlx/turboquant_kv.py']
    for name in paths:
        files[f'sources/{revision}/{name}'] = subprocess.check_output(
            ['git', 'show', f'{revision}:{name}'], cwd=root)
for name in ['serve_affine4_benchmark.py', 'bench_affine4_server.py']:
    files['scripts/' + name] = (root / 'benchmarks' / name).read_bytes()
files['sources/vlm-10f9030d-affine4.py'] = Path('/Users/ariel/opt/3party/mlx-vlm/mlx_vlm/affine4.py').read_bytes()
files['patches/omlx-generic-affine4.patch'] = subprocess.check_output(
    ['git', 'diff', '--binary', 'aa8db734', '99d314fd', '--', 'omlx', 'tests',
     'benchmarks/serve_affine4_benchmark.py', 'benchmarks/bench_affine4_server.py'], cwd=root)
logs = [
    temporary / 'omlx-affine4-comparison-20260907/incremental-server.log',
    temporary / 'omlx-affine4-comparison-20260907/final-server.log',
    temporary / 'omlx-affine4-comparison-20260907/restart-server.log',
    temporary / 'affine4-incremental-client.log',
    temporary / 'affine4-incremental-comparison.log',
    temporary / 'affine4-incremental-smoke.log',
    temporary / 'affine4-incremental-mtp-comparison.log',
    temporary / 'affine4-final-same-model.log',
    temporary / 'affine4-incremental-vmmap.txt',
    temporary / 'affine4-final-tests.log',
    temporary / 'affine4-partition-crossover.log',
    temporary / 'affine4-partition-threshold.log',
]
for path in logs:
    files['logs/' + path.name] = path.read_bytes()
settings = json.loads((temporary / 'omlx-affine4-comparison-20260907/settings.json').read_text())
files['server-memory-settings.json'] = (json.dumps({k: settings[k] for k in ['memory', 'cache', 'scheduler']}, indent=2)+'\n').encode()
files['README.md'] = b'''# Affine4 optimization validation

Apple M5 Pro, 48 GiB; MLX 0.32.2, mlx-lm 0.31.3, installed mlx-vlm 0.6.3.
The shared-model comparison imports the separate mlx-vlm checkout at 10f9030d.
The server uses installed mlx-vlm. Native model KV is BF16.
The included code/test/harness patch applies to oMLX upstream aa8db734 and
reconstructs the implementation through 99d314fd without needing private refs.

Scripts retain this machine's local paths. Adjust checkout, model and temporary
paths before replaying. Model weights are not included. Run GPU workloads
sequentially with other GPU jobs stopped. HTTP scripts mutate only the isolated
server's selected model settings and caches. No public upload is enabled.

Source mapping:
- decode_optimized: current=6805ce1f, baseline=423c2d35 (probes/affine4_baseline.py).
- prefill_optimized: current=41262a64, same baseline.
- query/mask_tuning: current=2f487029 plus the named isolated probe files.
- partition probes: current=probes/affine4_mask_tuning.py, before 99d314fd.
  Restore that source before replaying: their three-argument override predates
  the final dispatch's additional row-count argument.
- incremental large server: 2f487029. Mask/partition tuning came afterward.
- final shared model, server comparison and cache smoke: 99d314fd core.
The large server's empty-cache availability diagnostic was incorrect until
8617fa3f; chunk logs correctly record boundary_enabled=True.

Start serve_affine4_long.py with the isolated base path and port from the scripts.
Run run_affine4_incremental_comparison.py, then smoke.py cold. Stop and restart
the server before smoke.py restart, followed by smoke.py mtp.
The long script separately checks Qwen3.8 at 200K/150K and Qwen3.6 at 200K.

Original oMLX comparisons additionally require its compiled extension at
1ee0d24a; the previous affine4_regression_reproduction.zip contains that
investigation's source and harness. VLM cache source is included here.

One vmmap snapshot was taken during the Qwen3.8 200K prefill. Physical footprint
is sampled and is not the MLX active-allocation high-water mark. Shared-model
decode retains a native cache snapshot, so its memory is not standalone usage.
See adjacent JSON results and affine4_incremental_validation.md for protocols,
limitations, measured performance and cache lifecycle outcomes.
'''
manifest = {name: hashlib.sha256(content).hexdigest() for name, content in sorted(files.items())}
files['sha256.json'] = (json.dumps(manifest, indent=2)+'\n').encode()
archive = results / 'affine4_incremental_reproduction.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for name, content in sorted(files.items()):
        bundle.writestr(name, content)
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None
    assert all(hashlib.sha256(bundle.read(name)).hexdigest() == digest for name, digest in manifest.items())
print(f'{archive.name}: {len(files)} files, {archive.stat().st_size} bytes')
