import os
import json
import sys
from pathlib import Path

root = Path('/Users/ariel/opt/3party/omlx/.worktrees/generic-affine4')
sys.path.insert(0, str(root / 'benchmarks'))
import bench_affine4_server as bench

def focused_plan(models):
    for model in models:
        for mode in ('native16', 'tq4', 'affine4'):
            yield model, mode, 'comparison', [8192], 1024
        yield model, 'affine4', 'endurance', [8192], 4096

bench.plan = focused_plan
os.environ['OMLX_API_KEY'] = 'affine4-comparison'
sys.argv = [__file__, '--output', str(root / 'benchmarks/results/affine4_incremental_server_comparison.json')]
bench.main()
path = root / 'benchmarks/results/affine4_incremental_server_comparison.json'
data = json.loads(path.read_text())
data['method']['repeat'] = 'Focused single pass: all three formats at 8K/1024 generation, then Affine4 8K/4096 generation, for each model'
data['method']['implementation_commit'] = '99d314fd'
path.write_text(json.dumps(data, indent=2)+'\n')
