import copy
import gc
import hashlib
import importlib.util
import json
import statistics
import sys
import time
from pathlib import Path

root = Path('/Users/ariel/opt/3party/omlx/.worktrees/generic-affine4')
vlm_root = Path('/Users/ariel/opt/3party/mlx-vlm')
sys.path[:0] = [str(root),str(vlm_root)]
import mlx.core as mx
import omlx.affine4 as current
import mlx_vlm.affine4 as old
from mlx_vlm.models.cache import KVCache, make_prompt_cache
from mlx_vlm.turboquant import TurboQuantKVCache
from mlx_vlm.utils import load

model_path = Path('/Users/ariel/.omlx/models/Qwen3.6-35B-A3B-oQ4e-mtp')
context = int(sys.argv[1]) if len(sys.argv)>1 else 200000
count = 128
output = root/f'benchmarks/results/affine4_final_same_model_{context}.json'
data = {'protocol':{'model':str(model_path),'backend':'same mlx-vlm checkout for every cache',
                    'prompt_tokens':context,'decode_steps':count,'prefill_chunk':2048,
                    'prompt':'mlx.random.seed(20260906); randint(1000,100000)',
                    'decode':'teacher-forced native-BF16 greedy continuation; 8 untimed tokens warm each candidate; all candidates start from the same FP16-prefilled cache snapshot',
                    'skip_last':True,'MTP':False,'rotation_seed':0,'implementation':'bounded FP16 accumulator plus mask specialization; shared native-prefilled snapshot isolates decode',
                    'peak_memory':'Shared native snapshot retained; not a standalone model footprint'},
        'source_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [root/'omlx/affine4.py',vlm_root/'mlx_vlm/affine4.py',Path(__file__),model_path/'config.json']},'runs':[]}
def save():
    output.write_text(json.dumps(data,indent=2)+'\n')
model,_ = load(str(model_path))
lm = model.language_model
mx.random.seed(20260906)
prompt = mx.random.randint(1000,100000,(1,context))
mx.eval(prompt)
data['prompt_sha256']=hashlib.sha256(json.dumps(prompt[0].tolist(),separators=(',',':')).encode()).hexdigest()
base = make_prompt_cache(lm)
started=time.perf_counter()
for start in range(0,context,2048):
    out=lm(prompt[:,start:start+2048],cache=base,skip_logits=start+2048<context)
    if out.logits is not None:
        logits=out.logits[:,-1,:]
        mx.eval(logits)
    mx.eval([c.state for c in base])
    if start%32768==0:
        print(f'PREFILL {min(context,start+2048)}/{context}',flush=True)
data['prefill_seconds']=time.perf_counter()-started
first=int(mx.argmax(logits,axis=-1).item())
del out,logits
mx.clear_cache()
rope=copy.deepcopy((lm._rope_deltas,lm._position_ids))
attention_indices=[i for i,c in enumerate(base) if isinstance(c,KVCache)]
assert len(attention_indices)==10
data['quantized_layer_indices']=attention_indices[:-1]
data['native_key_dtype']=str(base[attention_indices[0]].keys.dtype)

def clone(scheme):
    caches=copy.deepcopy(base)
    cls={'vlm_pr':old.Affine4KVCache,'current':current.Affine4KVCache,
         'tq4':TurboQuantKVCache}.get(scheme)
    if cls:
        for i in attention_indices[:-1]:
            c=cls(bits=4,seed=0)
            c.update_and_fetch(*caches[i].state)
            caches[i]=c
    mx.eval([c.state for c in caches])
    lm._rope_deltas,lm._position_ids=copy.deepcopy(rope)
    return caches

native=clone('native_bf16')
continuation=[first]
for _ in range(count):
    logits=lm(mx.array([[continuation[-1]]]),cache=native).logits[:,-1,:]
    continuation.append(int(mx.argmax(logits,axis=-1).item()))
del native,logits
data['continuation']=continuation
save()
for scheme in ['current','vlm_pr','vlm_pr','current']:
    caches=clone(scheme)
    for token in continuation[:8]:
        mx.eval(lm(mx.array([[token]]),cache=caches).logits)
    del caches
    caches=clone(scheme)
    samples=[]
    top1=[]
    started=time.perf_counter()
    for token in continuation[:-1]:
        before=time.perf_counter_ns()
        logits=lm(mx.array([[token]]),cache=caches).logits[:,-1,:]
        prediction=mx.argmax(logits,axis=-1)
        mx.eval(prediction)
        samples.append((time.perf_counter_ns()-before)/1e6)
        top1.append(int(prediction.item()))
    elapsed=time.perf_counter()-started
    row={'scheme':scheme,'generation_tps':count/elapsed,'milliseconds_median':statistics.median(samples),
         'milliseconds_p10':sorted(samples)[12],'milliseconds_p90':sorted(samples)[115],
         'same_next_token_as_native':sum(a==b for a,b in zip(top1,continuation[1:])),
         'cache_bytes':sum(c.nbytes for c in caches),'peak_memory_bytes':mx.get_peak_memory(),
         'current_native':str(current._NATIVE_LAUNCHABLE),'old_native':str(old._NATIVE_LAUNCHABLE)}
    assert all(base[i].offset==context for i in attention_indices)
    data['runs'].append(row)
    save()
    print(json.dumps(row),flush=True)
    del caches,logits,prediction
    gc.collect()
    mx.clear_cache()
print('DONE',flush=True)
