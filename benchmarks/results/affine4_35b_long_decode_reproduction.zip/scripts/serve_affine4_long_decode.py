import json
import sys
from pathlib import Path
from types import SimpleNamespace

source, trace = sys.argv[1:3]
sys.path[:0] = [source, str(Path(source) / 'benchmarks')]
sys.argv = [sys.argv[0], *sys.argv[3:]]
import serve_affine4_benchmark as harness
harness._install_benchmark_overrides()
import omlx.admin.benchmark as benchmark
original = benchmark._run_single_test

async def timed(engine, prompt, max_tokens, pp_len, ane_trace_config=None):
    samples = []
    boundary = 512
    first_time = None
    last_count = 0
    async def stream_generate(**kwargs):
        nonlocal boundary, first_time, last_count
        async for output in engine.stream_generate(**kwargs):
            count = output.completion_tokens
            if count > last_count:
                start = getattr(output, 'generated_at', None)
                end = getattr(output, 'generated_until', None) or start
                if first_time is None and start is not None:
                    first_time = float(start)
                    samples.append({'tokens': 1, 'seconds': 0.0})
                if count >= boundary or output.finished:
                    if first_time is not None and end is not None:
                        samples.append({'tokens': count, 'seconds': float(end) - first_time})
                    boundary = (count // 512 + 1) * 512
                last_count = count
            yield output
    result = await original(SimpleNamespace(stream_generate=stream_generate), prompt, max_tokens, pp_len, ane_trace_config)
    result['decode_progress'] = samples
    Path(trace).write_text(json.dumps({'prompt_tokens': pp_len, 'decode_progress': samples}, indent=2) + '\n')
    return result

benchmark._run_single_test = timed
from omlx.cli import main
main()
