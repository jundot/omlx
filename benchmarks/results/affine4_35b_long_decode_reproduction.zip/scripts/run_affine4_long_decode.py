import copy
import hashlib
import json
import os
import socket
import subprocess
import sys
import time
from datetime import datetime, timezone
from importlib.metadata import version
from pathlib import Path

import httpx

SOURCE = Path('/Users/ariel/opt/3party/omlx/.worktrees/generic-affine4')
PYTHON = '/Users/ariel/opt/3party/omlx/.venv/bin/python'
MODEL = 'Qwen3.6-35B-A3B'
MODEL_PATH = Path('/Users/ariel/.omlx/models/Qwen3.6-35B-A3B-oQ4e-mtp')
ROOT = Path('/private/tmp/omlx-affine4-long-decode-20260907')
MANUAL = Path('/private/tmp/omlx-affine4-comparison-20260907')
PORT = 8004
KEY = 'affine4-long-decode-benchmark'
GENERATION = 4096
ROOT.mkdir(exist_ok=True)
sys.path.insert(0, str(SOURCE/'benchmarks'))
from bench_affine4_server import request, save, validate

output=ROOT/'results.json'
assert not output.exists(), 'Results already exist; avoid overwriting completed measurements'
with socket.socket() as probe:
    probe.settimeout(1)
    assert probe.connect_ex(('127.0.0.1',PORT))!=0, 'Benchmark port already occupied'
settings=json.loads((MANUAL/'settings.json').read_text())
model_settings=json.loads((MANUAL/'model_settings.json').read_text())['models'][MODEL]
protocol={'model':MODEL,'model_path':str(MODEL_PATH),'implementation_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip(),'hardware':'Apple M5 Pro, 48 GiB','versions':{p:version(p) for p in ('mlx','mlx-lm','mlx-vlm')},'contexts':[8192,200000],'generation_tokens':GENERATION,'prompt':'fixed code_python corpus, deterministic UUID, N+1 tokens for N prefill rows','sampler':'greedy; benchmark-only termination suppression','speculation':'MTP, VLM MTP, DFlash, SpecPrefill disabled','ane':False,'native_kv_dtype':'BF16','skip_last':True,'prefix_cache':'enabled, SSD only; a new empty base path per request, zero prefix hits required','warmup':'2048 prefill rows/up to 8 generated tokens, excluded','server_isolation':'fresh process and cache directory for every case; one GPU workload at a time','order':'8K native16,tq4,affine4; 200K affine4,tq4,native16; 200K native16,tq4,affine4','memory':{k:settings[k] for k in ('memory','cache','scheduler')},'public_upload':False,'limitations':'Generated continuations may differ between lossy formats; throughput, not a quality or teacher-forced comparison.'}
paths=[SOURCE/p for p in ['omlx/affine4.py','omlx/turboquant_kv.py','omlx/scheduler.py','omlx/admin/benchmark.py','benchmarks/serve_affine4_benchmark.py','benchmarks/bench_affine4_server.py']]+[Path(__file__),Path('/private/tmp/serve_affine4_long_decode.py'),MODEL_PATH/'config.json']
data={'protocol':protocol,'source_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},'started_at':datetime.now(timezone.utc).isoformat(),'runs':[]}
save(output,data)

restore=[]
with httpx.Client(base_url='http://127.0.0.1:8003',timeout=60,follow_redirects=True) as c:
    c.get('/admin/auto-login',params={'key':'affine4-comparison','redirect':'/admin/dashboard'}).raise_for_status()
    activity=request(c,'GET','/admin/api/activity')['active_models']
    assert not activity['total_active_requests'] and not activity['total_waiting_requests'], 'Manual server became busy'
    restore=[m['id'] for m in activity['models']]
    for model in restore: request(c,'POST',f'/admin/api/models/{model}/unload')
(ROOT/'manual_restore.json').write_text(json.dumps(restore)+'\n')

def environment():
    result={'time':datetime.now(timezone.utc).isoformat()}
    for name,command in {'thermal':['pmset','-g','therm'],'swap':['sysctl','vm.swapusage'],'vm':['vm_stat']}.items():
        p=subprocess.run(command,text=True,capture_output=True)
        result[name]=p.stdout+p.stderr
    return result

cases=[(8192,mode,1) for mode in ('native16','tq4','affine4')]
cases += [(200000,mode,1) for mode in ('affine4','tq4','native16')]
cases += [(200000,mode,2) for mode in ('native16','tq4','affine4')]
try:
    for context,mode,repeat in cases:
        label=f'{context}-{mode}-r{repeat}'
        base=ROOT/label
        (base/'models').mkdir(parents=True)
        (base/'models'/MODEL).symlink_to(MODEL_PATH)
        config=copy.deepcopy(settings)
        config['server']['port']=PORT
        config['model']['model_dirs']=[str(base/'models')]
        config['model']['model_dir']=str(base/'models')
        config['auth']={'api_key':KEY,'skip_api_key_verification':False,'sub_keys':[]}
        (base/'settings.json').write_text(json.dumps(config,indent=2))
        m=copy.deepcopy(model_settings)
        m.update(turboquant_kv_enabled=mode!='native16',turboquant_kv_scheme='affine4' if mode=='affine4' else 'turboquant',turboquant_kv_bits=4,turboquant_skip_last=True,mtp_enabled=False,vlm_mtp_enabled=False,dflash_enabled=False,specprefill_enabled=False,qwen35_ane_prefill_enabled=False,max_context_window=262144,max_tokens=8192,is_pinned=False)
        (base/'model_settings.json').write_text(json.dumps({'version':1,'models':{MODEL:m}},indent=2))
        row={'label':label,'context':context,'mode':mode,'repeat':repeat,'settings':m,'environment_start':environment()}
        data['runs'].append(row)
        save(output,data)
        env=os.environ.copy()
        env['PYTHONPATH']=str(SOURCE)
        env.pop('OMLX_AFFINE4_KV',None)
        with (base/'server.log').open('w') as log:
            process=subprocess.Popen([PYTHON,'/private/tmp/serve_affine4_long_decode.py',str(SOURCE),str(base/'decode_progress.json'),'serve','--base-path',str(base),'--host','127.0.0.1','--port',str(PORT),'--api-key',KEY],cwd=SOURCE,env=env,stdout=log,stderr=subprocess.STDOUT)
            print(f'START {label} pid={process.pid}',flush=True)
            try:
                with httpx.Client(base_url=f'http://127.0.0.1:{PORT}',timeout=60,follow_redirects=True) as client:
                    for _ in range(120):
                        if process.poll() is not None: raise RuntimeError(f'Server exited: {process.returncode}; {base}/server.log')
                        try:
                            client.get('/v1/models',headers={'Authorization':'Bearer '+KEY}).raise_for_status()
                            break
                        except httpx.HTTPError: time.sleep(1)
                    else: raise TimeoutError('Server startup')
                    client.get('/admin/auto-login',params={'key':KEY,'redirect':'/admin/dashboard'}).raise_for_status()
                    body={'model_id':MODEL,'prompt_lengths':[context],'generation_length':GENERATION,'batch_sizes':[],'warmup_mode':'ane_2048','align_prompt_to_ane':True,'force_lm_engine':False,'context_profile':'code_python'}
                    row['request']=body
                    row['bench_id']=request(client,'POST','/admin/api/bench/start',json=body)['bench_id']
                    notice=time.monotonic()
                    while True:
                        row['result']=request(client,'GET',f"/admin/api/bench/{row['bench_id']}/results")
                        save(output,data)
                        if row['result'].get('status')!='running':
                            row['validation_errors']=validate(row['result'],[context],GENERATION)
                            row['environment_end']=environment()
                            save(output,data)
                            print(json.dumps({'label':label,'results':row['result'].get('results',[]),'errors':row['validation_errors']}),flush=True)
                            if row['validation_errors']: raise RuntimeError(row['validation_errors'])
                            break
                        if time.monotonic()-notice>=30:
                            activity=request(client,'GET','/admin/api/activity')['active_models']
                            brief=[{k:m.get(k) for k in ('id','active_requests','prefilling','generating')} for m in activity['models']]
                            print(json.dumps({'label':label,'activity':brief}),flush=True)
                            notice=time.monotonic()
                        time.sleep(5)
            finally:
                process.terminate()
                try: process.wait(timeout=30)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()
        time.sleep(2)
    data['finished_at']=datetime.now(timezone.utc).isoformat()
    save(output,data)
finally:
    with httpx.Client(base_url='http://127.0.0.1:8003',timeout=90,follow_redirects=True) as c:
        c.get('/admin/auto-login',params={'key':'affine4-comparison','redirect':'/admin/dashboard'}).raise_for_status()
        for model in restore:
            print('RESTORE',model,request(c,'POST',f'/admin/api/models/{model}/load'),flush=True)
print('DONE '+str(output),flush=True)
