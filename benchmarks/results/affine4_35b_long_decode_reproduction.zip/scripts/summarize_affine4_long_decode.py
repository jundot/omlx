import json
import math
import re
import statistics
from collections import defaultdict
from pathlib import Path

root = Path('/private/tmp/omlx-affine4-long-decode-20260907')
data = json.loads((root / 'results.json').read_text())
groups = defaultdict(list)
prompts = defaultdict(set)
outputs = defaultdict(set)
rows = []
for run in data['runs']:
    if run.get('validation_errors') is None:
        continue
    assert run['validation_errors'] == [], run['label']
    assert run['result']['status'] == 'completed', run['label']
    result = run['result']['results'][0]
    assert result['prompt_tokens'] == run['context'] + 1
    assert result['completion_tokens'] == 4096
    assert result['cached_tokens'] == 0
    assert result['finish_reason'] == 'length'
    prompts[run['context']].add(result['prompt_sha256'])
    outputs[run['context'], run['mode']].add(result['output_sample']['sha256'])
    samples = result['decode_progress']
    assert samples[0] == {'tokens': 1, 'seconds': 0.0}
    assert samples[-1]['tokens'] == 4096
    rates = []
    for first, last in zip(samples, samples[1:]):
        assert last['tokens'] > first['tokens']
        assert last['seconds'] > first['seconds']
        rates.append((last['tokens'] - first['tokens']) / (last['seconds'] - first['seconds']))
    exact_tps = 4095 / samples[-1]['seconds']
    assert math.isclose(exact_tps, result['gen_tps'], abs_tol=0.1)
    def counter(environment, name):
        return int(re.search(rf'^{name}:\s+(\d+)', environment['vm'], re.M)[1])
    row = dict(label=run['label'], context=run['context'], mode=run['mode'],
               prefill_tps=result['processing_tps'], decode_tps=result['gen_tps'],
               exact_decode_tps=exact_tps, first_window_tps=rates[0], last_window_tps=rates[-1],
               mlx_peak_gib=result['peak_memory_bytes'] / 2**30,
               physical_peak_gib=result['system_metrics']['memory']['phys_footprint_peak'],
               thermal_max=result['system_metrics']['thermal']['max'],
               swapins=counter(run['environment_end'], 'Swapins') - counter(run['environment_start'], 'Swapins'),
               swapouts=counter(run['environment_end'], 'Swapouts') - counter(run['environment_start'], 'Swapouts'))
    rows.append(row)
    groups[(run['context'], run['mode'])].append(row)
assert all(len(hashes) == 1 for hashes in prompts.values())
assert all(len(hashes) == 1 for hashes in outputs.values())
summary = []
for (context, mode), values in sorted(groups.items()):
    summary.append(dict(context=context, mode=mode, n=len(values),
                        prefill_tps=statistics.mean(v['prefill_tps'] for v in values),
                        decode_tps=statistics.mean(v['decode_tps'] for v in values),
                        decode_range=[min(v['decode_tps'] for v in values), max(v['decode_tps'] for v in values)],
                        first_window_tps=statistics.mean(v['first_window_tps'] for v in values),
                        last_window_tps=statistics.mean(v['last_window_tps'] for v in values),
                        mlx_peak_gib=max(v['mlx_peak_gib'] for v in values),
                        physical_peak_gib=max(v['physical_peak_gib'] for v in values)))
indexed = {(s['context'], s['mode']): s for s in summary}
for item in summary:
    native = indexed.get((item['context'], 'native16'))
    if native:
        item['native_retention_percent'] = 100 * item['decode_tps'] / native['decode_tps']
    short = indexed.get((8192, item['mode']))
    if short:
        item['loss_vs_8k_percent'] = 100 * (1 - item['decode_tps'] / short['decode_tps'])
report = {'completed': len(rows), 'finished_at': data.get('finished_at'), 'runs': rows, 'summary': summary}
(root / 'summary.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
