Local Affine4 regression evidence, 2026-09-07.
Scripts retain absolute local checkout and model paths; adjust those constants before replaying elsewhere.
Use the existing oMLX Python environment with MLX 0.32.2. Run GPU workloads sequentially.
The legacy native probe needs the original oMLX compiled extension; its hash is recorded in affine4_history_attention.json beside this archive.
The half-accumulator changes are diagnostic process-local variants; they are unsafe for some shapes.
Server scripts target the isolated port 8003/base directory and use a synthetic benchmark API key.
Aligned admin prompts keep public benchmark uploads disabled.
The tested_source copy preserves the unchanged Affine4 implementation used in this investigation.
