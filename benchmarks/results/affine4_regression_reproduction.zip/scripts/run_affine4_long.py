import hashlib
import json
import sys
import time
from pathlib import Path

import httpx

root = Path('/Users/ariel/opt/3party/omlx/.worktrees/generic-affine4')
sys.path.insert(0, str(root / 'benchmarks'))
from bench_affine4_server import request, save, validate

path = root / 'benchmarks/results/affine4_large_context_server.json'
data = {'protocol': {'mode': 'affine4', 'generation_tokens': 128, 'MTP': False,
                     'context': '100000/150000/200000 prefill rows plus one prompt token',
                     'cold_cache': True, 'memory_guard': 'balanced, unchanged',
                     'public_upload': False},
        'source_sha256': {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in
                         [root/'omlx/affine4.py',Path('/private/tmp/serve_affine4_long.py'),Path(__file__)]}, 'runs': []}
if path.exists():
    data=json.loads(path.read_text())
data.setdefault('runner_revisions',[]).append(hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
save(path,data)
with httpx.Client(base_url='http://127.0.0.1:8003',timeout=60,follow_redirects=True) as client:
    client.get('/admin/auto-login',params={'key':'affine4-comparison','redirect':'/admin/dashboard'}).raise_for_status()
    previous = None
    for model in ['Qwen3.6-35B-A3B', 'Qwen3.8-27B']:
        if previous:
            response=client.post(f'/admin/api/models/{previous}/unload')
            if response.status_code != 400:
                response.raise_for_status()
        settings = {'turboquant_kv_enabled':True,'turboquant_kv_scheme':'affine4','turboquant_kv_bits':4,
                    'turboquant_skip_last':True,'mtp_enabled':False,'vlm_mtp_enabled':False,'dflash_enabled':False,
                    'specprefill_enabled':False,'qwen35_ane_prefill_enabled':False,'max_context_window':262144,'max_tokens':8192}
        request(client,'PUT',f'/admin/api/models/{model}/settings',json=settings)
        for length in [100000,150000,200000]:
            if any(r['model']==model and r['context']==length and r.get('result',{}).get('status') in ['completed','error','cancelled'] for r in data['runs']):
                continue
            for cache in ['ssd-cache','hot-cache']:
                request(client,'POST',f'/admin/api/{cache}/clear',json={})
            body = {'model_id':model,'prompt_lengths':[length],'generation_length':128,'batch_sizes':[],
                    'warmup_mode':'ane_2048','align_prompt_to_ane':True,'force_lm_engine':False,'context_profile':'code_python'}
            run = {'model':model,'context':length,'settings':settings,'request':body}
            data['runs'].append(run)
            started = request(client,'POST','/admin/api/bench/start',json=body)
            run['bench_id'] = started['bench_id']
            save(path,data)
            print(f'START {model} {length}',flush=True)
            notice = time.monotonic()
            while True:
                result = request(client,'GET',f"/admin/api/bench/{run['bench_id']}/results")
                run['result'] = result
                save(path,data)
                if result.get('status') != 'running':
                    run['validation_errors'] = validate(result,[length],128)
                    save(path,data)
                    print(json.dumps({'model':model,'context':length,'result':result,'validation_errors':run['validation_errors']}),flush=True)
                    break
                if time.monotonic()-notice >= 30:
                    activity = request(client,'GET','/admin/api/activity')
                    print(json.dumps({'model':model,'context':length,'activity':activity}),flush=True)
                    notice = time.monotonic()
                time.sleep(5)
        previous = model
print('DONE',flush=True)
