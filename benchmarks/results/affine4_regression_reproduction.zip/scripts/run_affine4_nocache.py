import json
import sys
import time
from pathlib import Path

import httpx

root=Path('/Users/ariel/opt/3party/omlx/.worktrees/generic-affine4')
sys.path.insert(0,str(root/'benchmarks'))
from bench_affine4_server import request,save,validate

with httpx.Client(base_url='http://127.0.0.1:8003',timeout=60,follow_redirects=True) as c:
    c.get('/admin/auto-login',params={'key':'affine4-comparison','redirect':'/admin/dashboard'}).raise_for_status()
    for cache in ['ssd-cache','hot-cache']:
        request(c,'POST',f'/admin/api/{cache}/clear',json={})
    body={'model_id':'Qwen3.8-27B','prompt_lengths':[200000],'generation_length':128,'batch_sizes':[],
          'warmup_mode':'ane_2048','align_prompt_to_ane':True,'force_lm_engine':False,'context_profile':'code_python'}
    started=request(c,'POST','/admin/api/bench/start',json=body)
    data={'protocol':'200K with prefix caching disabled and adaptive prefill; same model, input, generation, and memory limits',
          'request':body,'bench_id':started['bench_id']}
    output=root/'benchmarks/results/affine4_large_context_no_prefix_cache.json'
    save(output,data)
    print('START no-prefix-cache 200K',flush=True)
    while True:
        activity=request(c,'GET','/admin/api/activity')
        models=activity.get('active_models',{}).get('models',[])
        if any(m['id']=='Qwen3.8-27B' and not m.get('is_loading') for m in models):
            changed=request(c,'POST','/admin/api/global-settings',json={'prefill_priority':'context'})
            data['policy_switch']={'activity':activity,'runtime_applied':changed.get('runtime_applied')}
            save(output,data)
            break
        result=request(c,'GET',f"/admin/api/bench/{data['bench_id']}/results")
        if result.get('status')!='running':
            break
        time.sleep(1)
    while True:
        result=request(c,'GET',f"/admin/api/bench/{data['bench_id']}/results")
        data['result']=result
        save(output,data)
        if result.get('status')!='running':
            data['validation_errors']=validate(result,[200000],128)
            save(output,data)
            print(json.dumps(data),flush=True)
            break
        time.sleep(5)
print('DONE',flush=True)
