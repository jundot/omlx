import hashlib
import json
import random
import statistics
import sys
import time
from pathlib import Path

root = Path('/Users/ariel/opt/3party/omlx/.worktrees/generic-affine4')
vlm_root = Path('/Users/ariel/opt/3party/mlx-vlm')
sys.path[:0] = [str(root),str(vlm_root)]
import mlx.core as mx
from omlx.affine4 import Affine4KVCache
from mlx_vlm.affine4 import Affine4KVCache as VLMAffine4
from mlx_vlm.models.base import scaled_dot_product_attention

data = {'protocol':'BF16 Q/K/V, T=32768, causal prefill; 3 warmups and 11 randomized interleaved rounds. BF16 rotated SDPA is a diagnostic only.',
        'source_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [root/'omlx/affine4.py',vlm_root/'mlx_vlm/affine4.py',Path(__file__)]},'rows':[]}
output = Path('/private/tmp/affine4_history_prefill.json')
for hq,hkv in [(24,4),(16,2)]:
    mx.random.seed(44)
    k = mx.random.normal((1,hkv,32768,256),dtype=mx.bfloat16)
    v = mx.random.normal(k.shape,dtype=mx.bfloat16)
    current,old = Affine4KVCache(),VLMAffine4()
    current.update_and_fetch(k,v)
    old.update_and_fetch(k,v)
    mx.eval(current.state,old.state,k,v)
    for qlen in [256,2048]:
        q = mx.random.normal((1,hq,qlen,256),dtype=mx.bfloat16)
        mx.eval(q)
        def bf16_probe(force_fused=False):
            ck,cv = current.state
            kr = current.key_codec.dequantize_rotated(ck).astype(mx.bfloat16)
            vr = current.value_codec.dequantize_rotated(cv).astype(mx.bfloat16)
            qr = current.key_codec.prepare_queries(q).astype(mx.bfloat16)
            out = mx.fast.scaled_dot_product_attention(qr,kr,vr,scale=256**-.5,mask='causal',force_fused=force_fused)
            return current.value_codec._rotate_inverse(out.astype(mx.float32)).astype(q.dtype)
        def legacy():
            return scaled_dot_product_attention(q,*old.state,old,scale=256**-.5,mask='causal')
        cases = {'current':lambda:current.attention(q,scale=256**-.5,mask='causal'),
                 'vlm_pr':legacy,'current_bf16_sdpa_probe':bf16_probe,
                 'current_bf16_fused_sdpa_probe':lambda:bf16_probe(True),
                 'native_bf16':lambda:mx.fast.scaled_dot_product_attention(q,k,v,scale=256**-.5,mask='causal')}
        for _ in range(3):
            for call in cases.values():
                mx.eval(call())
        samples={name:[] for name in cases}
        rng=random.Random(55)
        for _ in range(11):
            order=list(cases)
            rng.shuffle(order)
            for name in order:
                start=time.perf_counter_ns()
                mx.eval(cases[name]())
                samples[name].append((time.perf_counter_ns()-start)/1e6)
        base=current.attention(q,scale=256**-.5,mask='causal').astype(mx.float32)
        probe=bf16_probe().astype(mx.float32)
        cosine=mx.sum(base*probe)/(mx.sqrt(mx.sum(base*base))*mx.sqrt(mx.sum(probe*probe)))
        row={'query_heads':hq,'kv_heads':hkv,'tokens':32768,'query_length':qlen,
             'milliseconds':{name:statistics.median(values) for name,values in samples.items()},
             'bf16_probe_cosine_vs_current':float(cosine)}
        data['rows'].append(row)
        output.write_text(json.dumps(data,indent=2)+'\n')
        print(json.dumps(row),flush=True)
print('DONE',flush=True)
