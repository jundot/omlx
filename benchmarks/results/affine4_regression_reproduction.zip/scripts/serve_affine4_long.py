import sys
from pathlib import Path

root = Path('/Users/ariel/opt/3party/omlx/.worktrees/generic-affine4')
sys.path[:0] = [str(root), str(root / 'benchmarks')]
import omlx.admin.benchmark as bench
from serve_affine4_benchmark import main

bench.VALID_PROMPT_LENGTHS = sorted(set(bench.VALID_PROMPT_LENGTHS) | {100000, 150000})
main()
