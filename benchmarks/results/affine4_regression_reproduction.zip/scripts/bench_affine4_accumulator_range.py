import importlib.util
import json
import sys
from pathlib import Path

root=Path('/Users/ariel/opt/3party/omlx/.worktrees/generic-affine4')
sys.path[:0]=[str(root),'/Users/ariel/opt/3party/mlx-vlm']
import mlx.core as mx
import omlx.affine4 as current
import mlx_vlm.affine4 as legacy
from mlx_vlm.turboquant import TurboQuantMSEState

spec=importlib.util.spec_from_file_location('omlx.affine4_half_probe',root/'omlx/affine4.py')
half=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=half
spec.loader.exec_module(half)
half._MPP_HEADER=half._MPP_HEADER.replace('decltype(p_tensor), decltype(v_first), float>()','decltype(p_tensor), decltype(v_first), half>()')
tokens,heads,dim=32768,64,32
keys=TurboQuantMSEState(mx.ones((1,heads,tokens)),mx.zeros((1,heads,tokens,dim//8),dtype=mx.uint32))
values=TurboQuantMSEState(mx.ones((1,heads,tokens)),mx.full((1,heads,tokens,dim//8),0x88888888,dtype=mx.uint32))
q=mx.zeros((1,heads,1,dim),dtype=mx.bfloat16)
mx.eval(keys,values,q)
data={'geometry':{'tokens':tokens,'kv_heads':heads,'query_heads':heads,'dim':dim},
      'protocol':'Zero queries/keys, constant signed -8 value codes with scale 1: exact rotated attention output is -8.',
      'blocks':current._attention_blocks(tokens,heads,dim),'tokens_per_block':8192,'absolute_partial_sum':65536,'fp16_max':65504,'rows':[]}
for name,module in [('current',current),('half_accumulator_probe',half),('vlm_pr',legacy)]:
    cache=module.Affine4KVCache()
    cache.key_codec=module.Affine4Codec(dim,0)
    cache.value_codec=module.Affine4Codec(dim,1)
    ks=TurboQuantMSEState(keys.norms.astype(mx.float16),keys.indices) if module is legacy else keys
    vs=TurboQuantMSEState(values.norms.astype(mx.float16),values.indices) if module is legacy else values
    out=module._native_attention(cache,q,ks,vs,dim**-.5,None)
    assert out is not None
    mx.eval(out)
    finite=bool(mx.all(mx.isfinite(out)).item())
    reference=cache.value_codec._rotate_inverse(mx.full(q.shape,-8.0)).astype(q.dtype)
    data['rows'].append({'scheme':name,'all_finite':finite,'max_absolute_error':float(mx.max(mx.abs(out-reference)).item()) if finite else None})
print(json.dumps(data),flush=True)
(root/'benchmarks/results/affine4_accumulator_range.json').write_text(json.dumps(data,indent=2)+'\n')
