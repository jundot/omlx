import json
from datetime import datetime,timezone
from pathlib import Path
import httpx

with httpx.Client(base_url='http://127.0.0.1:8003',timeout=60,follow_redirects=True) as c:
    c.get('/admin/auto-login',params={'key':'affine4-comparison','redirect':'/admin/dashboard'}).raise_for_status()
    before=c.get('/admin/api/activity')
    before.raise_for_status()
    changed=c.post('/admin/api/global-settings',json={'prefill_priority':'context'})
    changed.raise_for_status()
    record={'changed_at':datetime.now(timezone.utc).isoformat(),'change':{'prefill_priority':'context'},'memory_guard':'unchanged',
            'activity_at_switch':before.json(),'applied':{k:v for k,v in changed.json().items() if k in ['success','status','runtime_applied']}}
    Path('/private/tmp/affine4_large_context_adaptive_switch.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record),flush=True)
